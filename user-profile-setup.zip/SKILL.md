---
name: user-profile-setup
version: 1.0.0
license: MIT
description: "Build, audit, and fix production user profile editors, cropped and cache-busted avatar/cover uploads, @username uniqueness, self-hiding completeness checklists, and first-run onboarding wizards. Includes an offline static scanner for React, Next.js, and Supabase."
compatibility: "Works with Claude Code, Cursor, Codex CLI, VS Code Copilot, Windsurf, Gemini CLI, and any SKILL.md-compatible agent. Optimized for React, Next.js, TypeScript, and Supabase/Prisma/Drizzle. Python 3.8+ (stdlib only) optional for the offline static scanner."
---

# User Profile Setup

Production workflow for designing, auditing, and shipping personal profile editors (`/profile`), first-run onboarding wizards (`/onboarding`), media uploads (avatars and cover banners), structured sub-lists (skills, tags, experience, social links, endorsements), and verification-readiness checklists.

## When to Use

Activate this skill when the user asks to:
- Build or redesign a personal `/profile`, account profile settings, or `/onboarding` setup flow
- Add or fix avatar/cover photo upload, client-side cropping, removal, or browser cache-busting
- Implement `@username` / handle normalization, format validation, and duplicate-handle error states
- Add profile completeness indicators, onboarding completion guards, or verification eligibility cards
- Manage profile sub-collections (skills, tags, portfolio items, work history, pinned/hidden endorsements)
- Audit an existing profile or onboarding flow for UX bugs, data waterfalls, accessibility gaps, or data leaks

Do **not** use this skill for:
- Authentication provider setup (OAuth/SSO configuration, password reset tokens, session middleware)
- Billing, subscription checkout, or Stripe webhook pipelines
- Global search/discovery ranking algorithms unrelated to profile fields

## Four Operating Modes

- **BUILD** — Scaffold or extend profile setup, media upload, completeness, or onboarding flows using the host project's existing UI primitives and data layer.
- **AUDIT** — Read-only static + manual inspection using `scripts/audit_profile_flow.py`. Maps concrete bugs to `file:line` with severity and fix direction. Modifies nothing.
- **REFINE** — Apply minimal, surgical patches to fix findings or ship requested UX upgrades while preserving optimistic state, rollback snapshots, and toast feedback.
- **VERIFY** — Re-run the scanner plus the project's typecheck/test suite and report before/after deltas.

---

## Step 0 — Stack & Scope Intake

Inspect `package.json`, route directories, and existing auth/database helpers first. Only ask the user if an answer cannot be inferred from the repository; otherwise record detected defaults and proceed.

| Dimension | Inspect in repo | How this skill adapts |
|---|---|---|
| **Framework & Router** | `app/` (Next.js App Router), `pages/`, `src/routes/` (Remix / SvelteKit / TanStack) | Keep interactive editors in focused client hooks/components; keep route shells lean. |
| **Data & Storage Layer** | `@supabase/supabase-js`, `@prisma/client`, `drizzle-orm`, `firebase`, or `/api/*` | Use `references/state-and-save-patterns.md` and `references/public-vs-owner-security.md` for query filters, unique constraint codes (`23505` / `P2002`), and storage bucket rules. |
| **UI Primitives & Toasts** | `components/ui/*` (shadcn / Radix / Base UI), `sonner`, `react-hot-toast` | Reuse existing `Button`, `Input`, `Select`, `Card`, `Badge`, `Dialog`, and toast helpers. Never add duplicate UI libraries. |
| **Target Surface** | Owner editor (`/profile`), public view (`/profile/[id]`, `/u/[handle]`), wizard (`/onboarding`), trust (`/verify`) | Enforce strict route boundaries (see **Decision Boundaries** below). |
| **Requested Mode** | User prompt intent | Run **AUDIT** first when debugging/reviewing; run **BUILD** or **REFINE** when shipping features; always close code changes with **VERIFY**. |

---

## Mode 1 — BUILD (Architecture Blueprint)

When building or extending a profile setup experience, implement these seven production patterns cleanly:

1. **Separate Owner Editor from Public Profile Route**
   - Keep owner-only editing state, hidden items, and completeness prompts on `/profile` (or `/settings/profile`).
   - Keep `/profile/[id]` or `/u/[username]` read-only with explicit column selection (never `select('*')` if private/moderation columns exist) and filter out `hidden` endorsements/items in the query.
   - Read `references/public-vs-owner-security.md` before writing queries or RLS policies.

2. **Snapshot & Rollback Edit State**
   - Maintain both `form` (live draft) and `snapshot` (last saved state).
   - `handleCancel()` must restore `setForm(snapshot)` and exit edit mode cleanly without refetching the page.
   - Disable the primary Save button while `saving` is true to prevent duplicate writes.
   - Full pattern: `references/state-and-save-patterns.md`.

3. **Parallel Hydration (`Promise.all`)**
   - Fetch the core profile row, skills/tags, experiences, badges, and endorsements concurrently via `Promise.all` instead of sequential `await` waterfalls.

4. **Cropped, Validated, Cache-Busted Media Uploads**
   - Hide `<input type="file" accept="image/*" />` behind an accessible trigger (`aria-label="Change photo"`) and immediately reset `e.target.value = ''` inside `onChange` so cancelling a crop dialog and re-picking the same file still fires `onChange`.
   - Enforce client-side file size limits before upload (e.g., 2 MB avatars, 5 MB covers) and open a 1:1 round crop dialog for avatars or wide aspect crop for covers.
   - When overwriting deterministic storage paths (`${userId}/avatar.${ext}` with `upsert: true`), append a cache-busting query token (`${publicUrl}?t=${Date.now()}`) when updating UI state so browsers do not display stale cached images.
   - Full pipeline: `references/media-upload-and-cropping.md`.

5. **Handle Normalization & Conflict Feedback**
   - Trim and lowercase `@username` handles (`username.trim().toLowerCase()`), validate with `/^[a-z0-9_.-]{2,32}$/` before network calls, and map database unique-violation codes (Postgres `23505`, Prisma `P2002`) to `"That username is already taken"`.

6. **Immediate Sub-Collection Updates (Pin, Hide, Add, Remove)**
   - Update local state arrays immediately after insert/delete/pin/hide mutations without full-page reloads.
   - Scope every mutation by **both** primary key and owner (`eq('id', itemId).eq('user_id', user.id)`) for defense-in-depth alongside RLS.
   - Normalize `<input type="month">` values (`YYYY-MM` -> `YYYY-MM-01`) before inserting into SQL `date` columns.

7. **Self-Hiding Completeness & Onboarding Guard**
   - Compute profile completeness from 5–7 high-value signals (photo, headline, bio, location, primary tags/skills) and return `null` at `100%` so completed profiles stay uncluttered.
   - In `/onboarding`, check `onboarding_completed` on mount and redirect returning users straight to the app home/dashboard.
   - Full guide: `references/onboarding-and-completeness.md`.

---

## Mode 2 — AUDIT (Read-Only Scan & Diagnosis)

1. Run the bundled offline static analyzer against the target repository (Python 3 stdlib only, zero network calls, zero file modifications):

   ```bash
   python3 -B scripts/audit_profile_flow.py <project-dir> --format json
   ```

   - Exit code `0`: no medium/high findings detected.
   - Exit code `1`: at least one medium or high finding requires attention.
   - Pass `--format text` for a human-readable summary.

2. Read every flagged file around the reported line numbers to confirm context and eliminate false positives, then perform a targeted manual check for:
   - Missing snapshot rollback on Cancel
   - Unreachable keyboard/touch controls (`< 44x44px` tap targets or missing focus ring)
   - Onboarding re-entry loops (`onboarding_completed` not persisted or checked)

3. Deliver the report in this exact structure:

```markdown
# Profile & Onboarding Audit — <project-name>
Stack: <framework + db + ui> · Files scanned: <N>
Findings: <total> (High: <h>, Medium: <m>, Low: <l>)

## Ranked Findings
### 1. [HIGH] <rule-id>: <short title> — `<file>:<line>`
- **What happens:** <concrete behavior in the current code>
- **User / security impact:** <stale avatar cache, mass-update risk, silent file-reselect failure, waterfall latency, etc.>
- **Recommended fix:** <1–2 sentences describing the minimal patch>

## Passed Checks & Scope Notes
- <what is already solid + any runtime policies like DB RLS that require SQL inspection>
```

---

## Mode 3 — REFINE (Surgical Implementation Rules)

- **Smallest complete diff:** Modify only the routes, hooks, and components needed for the requested improvement or approved audit batch.
- **Component fidelity:** Match existing spacing, typography, dark-mode tokens, and component props (for example, respect Radix `asChild` vs Base UI `render={...}` conventions in the host repo).
- **Preserve UX contracts:** Keep loading spinners, disabled button states (`saving`, `uploadingAvatar`, `togglingId`), and toast notifications consistent with surrounding screens.
- **Explicit owner scoping:** Never ship a client-initiated `update` or `delete` on profile sub-tables without scoping to the authenticated user's ID in addition to row ID.

---

## Mode 4 — VERIFY (Post-Change Validation)

After applying changes in **BUILD** or **REFINE**:

1. Re-run `python3 -B scripts/audit_profile_flow.py <project-dir> --format text` and confirm fixed findings are resolved with zero regressions introduced.
2. Run the project's typecheck and relevant unit tests (e.g., `npx tsc --noEmit`, `npm test`).
3. Verify the five functional acceptance gates:
   - Profile field edits persist on Save and revert cleanly to `snapshot` on Cancel.
   - Avatar/cover upload enforces size limits, resets file input on cancel, and busts browser cache on overwrite.
   - Username/handle collisions surface a specific user-facing message instead of a generic failure.
   - Sub-item add/remove/pin/hide updates UI state immediately without full-page reload.
   - Public profile view excludes hidden items and private columns.

---

## Decision Boundaries

- **Owner editor vs. public profile:** Keep edits in `/profile` unless the user explicitly asks to change public profile display or SEO metadata (`/profile/[id]` or `/u/[username]`).
- **Onboarding vs. verification:** When the request mentions trust badges, identity checks, or verification progress, inspect `/verify` (or equivalent) and connect incomplete profile criteria back to `/profile` with direct fix links.
- **Search & matching coupling:** If adding or renaming skill/tag fields on `/profile`, keep existing column contracts intact so downstream browse/search pages do not break.

## Bundled References & Examples

- [State, Hydration & Save Patterns](references/state-and-save-patterns.md) — Snapshot rollback, parallel loading, handle validation, optimistic sub-lists.
- [Media Upload & Cropping Pipeline](references/media-upload-and-cropping.md) — Hidden file inputs, 1:1/banner crop flow, size/MIME checks, `?t=` cache-busting, storage policies.
- [Onboarding, Completeness & Verification](references/onboarding-and-completeness.md) — Multi-step wizard guard, searchable country/tag selectors, auto-hiding completeness card, trust gates.
- [Public vs. Owner Security & RLS](references/public-vs-owner-security.md) — Column privacy, hidden endorsement filtering, owner-scoped writes, Postgres/Supabase RLS templates.
- [Worked Session Example](examples/real-session-audit-and-patch.md) — End-to-end walkthrough of an audit scan, ranked report, surgical patch, and verification delta.
