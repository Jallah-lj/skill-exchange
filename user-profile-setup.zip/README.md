# User Profile Setup — Universal Agent Skill (`SKILL.md`)

Production-grade workflow and static analyzer for building, auditing, and refining **user profile editors (`/profile`)**, **avatar & cover upload pipelines**, **`@username` handle validation**, **profile completeness checklists**, **sub-collection editors (skills, tags, experience, endorsements)**, and **first-run onboarding wizards (`/onboarding`)**.

Follows the open **Universal `SKILL.md` Standard** and works with Claude Code, Cursor, Codex CLI, VS Code Copilot, Windsurf, Gemini CLI, and any `SKILL.md`-compatible agent.

## What's Inside

- **`SKILL.md`** — Core 4-mode workflow (**BUILD**, **AUDIT**, **REFINE**, **VERIFY**) with automatic stack intake and strict owner-vs-public route boundaries.
- **`scripts/audit_profile_flow.py`** — Zero-dependency, offline, read-only Python 3 static scanner that maps real profile & upload bugs (`PF001`–`PF008`) to exact `file:line` locations in `--format text` or `--format json`.
- **`references/state-and-save-patterns.md`** — Snapshot/rollback edit state, parallel `Promise.all` hydration, `@username` validation + Postgres `23505` / Prisma `P2002` conflict handling, and `<input type="month">` normalization.
- **`references/media-upload-and-cropping.md`** — Hidden file inputs with same-file re-select reset, accessible overlay buttons, client-side cropping, size guards, and `?t=` URL cache-busting on `upsert: true` storage keys.
- **`references/onboarding-and-completeness.md`** — First-run `onboarding_completed` guard, searchable country/tag selectors, auto-hiding completeness card, and verification/KYC eligibility deep-linking.
- **`references/public-vs-owner-security.md`** — Preventing `select('*')` data leaks on public `/profile/[id]` routes, filtering `hidden` social proof in queries, owner-scoped writes, and idempotent RLS policies.
- **`examples/real-session-audit-and-patch.md`** — Full worked session showing scanner findings, minimal patches, and post-fix verification.

## Quick Start

### Install in Your Agent
Extract `user-profile-setup/` into your agent's skills directory:
- **Claude Code:** `.claude/skills/user-profile-setup/` (workspace) or `~/.claude/skills/user-profile-setup/` (global)
- **Cursor / Codex / Copilot / Other `SKILL.md` clients:** Place in your configured skills directory or install directly from Agensi.

### Example Prompts
- *"Audit our `/profile` and `/onboarding` pages and give me a ranked fix plan."*
- *"Build a personal `/profile` editor with cropped avatar upload, `@username` uniqueness handling, and a self-hiding profile completeness checklist."*
- *"Fix stale cached avatars after re-upload and make sure public `/profile/[id]` routes don't leak private profile columns."*

### Run the Bundled Scanner Directly (Optional)
```bash
python3 -B scripts/audit_profile_flow.py /path/to/your-app --format text
python3 -B scripts/audit_profile_flow.py /path/to/your-app --format json
```
