# State, Hydration & Save Patterns

Production patterns for managing profile form state, parallel loading, `@username` validation, and sub-collection mutations without stale state or page flickers.

## 1. Snapshot & Rollback Edit State

Keep `form` (current editable values) separate from `snapshot` (last persisted server values) so cancelling edits reverts cleanly without an extra network round-trip.

```tsx
const [form, setForm] = useState<ProfileFormState>(EMPTY_FORM)
const [snapshot, setSnapshot] = useState<ProfileFormState>(EMPTY_FORM)
const [isEditing, setIsEditing] = useState(false)
const [saving, setSaving] = useState(false)

const updateForm = (patch: Partial<ProfileFormState>) =>
  setForm((prev) => ({ ...prev, ...patch }))

const handleEdit = () => setIsEditing(true)

const handleCancel = () => {
  setForm(snapshot)
  setIsEditing(false)
}
```

When `saveProfile()` succeeds:
1. Normalize fields (e.g., trimmed/lowercased `username`, nullable empty URLs).
2. Update `setSnapshot(normalizedForm)` so subsequent Cancel actions revert to the newly saved values.
3. Exit edit mode (`setIsEditing(false)`) and trigger toast feedback.

## 2. Parallel Hydration (`Promise.all`)

Profile pages frequently combine 4–6 tables (core profile, skills/tags, work history, endorsements/testimonials, badges). Never chain sequential `await` calls when queries depend only on `user.id`:

```tsx
const [
  { data: profile },
  { data: skills },
  { data: endorsements },
  { data: experiences },
  { data: badges },
] = await Promise.all([
  db.from('profiles').select('*').eq('id', user.id).single(),
  db.from('user_skills').select('*').eq('user_id', user.id),
  db
    .from('endorsements')
    .select('id, endorser_id, skill_name, created_at, pinned, hidden, endorser:profiles!endorser_id(id, name, avatar_url)')
    .eq('endorsee_id', user.id)
    .order('pinned', { ascending: false })
    .order('created_at', { ascending: false }),
  db
    .from('experiences')
    .select('*')
    .eq('user_id', user.id)
    .order('start_date', { ascending: false, nullsFirst: false }),
  db.from('user_badges').select('badge_type').eq('user_id', user.id),
])
```

## 3. `@username` Normalization & Unique Violation Handling

Always normalize handles before client validation and map database unique-constraint errors explicitly:

```tsx
const cleanUsername = form.username.trim().toLowerCase()
if (!/^[a-z0-9_.-]{2,32}$/.test(cleanUsername)) {
  toast.error('Username must be 2–32 characters: letters, numbers, "_", "." or "-" only')
  return
}

const { error } = await db
  .from('profiles')
  .update({
    name: form.name.trim(),
    username: cleanUsername,
    headline: form.headline.trim(),
    bio: form.bio.trim(),
    location: form.location,
    website_url: form.websiteUrl.trim() || null,
  })
  .eq('id', user.id)

if (error) {
  // Postgres 23505 or Prisma P2002 = unique constraint violation
  const isDuplicate = error.code === '23505' || error.code === 'P2002'
  toast.error(isDuplicate ? 'That username is already taken' : 'Failed to save profile')
  return
}
```

## 4. Sub-Collection Mutations (Skills, Tags, Experiences, Endorsements)

### Pinned-First Sorting Helper
```tsx
const byPinnedFirst = <T extends { pinned?: boolean }>(a: T, b: T) =>
  Number(!!b.pinned) - Number(!!a.pinned)
```

### Owner-Scoped Delete & Toggle
Always scope mutations by both `id` and the owner column (`user_id` or `endorsee_id`) even when Row-Level Security (RLS) is enabled:

```tsx
const removeSkill = async (id: string) => {
  const { error } = await db
    .from('user_skills')
    .delete()
    .eq('id', id)
    .eq('user_id', userId)

  if (error) {
    toast.error('Failed to remove skill')
    return
  }
  setSkills((prev) => prev.filter((item) => item.id !== id))
}
```

### `<input type="month">` Date Normalization
HTML `<input type="month">` emits `"YYYY-MM"`, which Postgres `date` columns reject unless padded to a valid day:

```tsx
const normalizeMonth = (value: string) =>
  value.length === 7 ? `${value}-01` : value || null
```
