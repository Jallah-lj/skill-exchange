# Public vs. Owner Security & RLS

User profile systems have two distinct audiences: the **authenticated owner** editing their own profile (`/profile`) and **visitors** viewing a public profile (`/profile/[id]` or `/u/[username]`). Blurring these two surfaces is the #1 source of privacy leaks in full-stack apps.

## 1. Never `select('*')` on Public Profile Routes

Over time, `profiles` tables accumulate internal moderation, contact, and billing columns (`email`, `phone`, `banned`, `suspended`, `ban_reason`, `stripe_customer_id`, `kyc_notes`). Public routes must project an explicit public column allowlist:

```tsx
const PUBLIC_PROFILE_COLUMNS = [
  'id',
  'name',
  'username',
  'headline',
  'bio',
  'location',
  'availability',
  'avatar_url',
  'cover_image_url',
  'website_url',
  'github_url',
  'linkedin_url',
  'kyc_status',
  'created_at',
].join(', ')

const { data: publicProfile } = await db
  .from('profiles')
  .select(PUBLIC_PROFILE_COLUMNS)
  .eq('id', targetUserId)
  .single()
```

Apply the same rule to joined relation selects (e.g., `reviewer:profiles!reviewer_id(id, name, avatar_url)` instead of `reviewer:profiles!reviewer_id(*)`).

## 2. Respect `hidden` Flags on Public Endorsements & Testimonials

On `/profile` (owner view), load all received endorsements so the owner can toggle `pinned` and `hidden`.
On `/profile/[id]` (public view), filter hidden items in the database query itself — not just in React rendering — so hidden items cannot be inspected in DevTools network responses:

```tsx
const { data: endorsements } = await db
  .from('endorsements')
  .select('skill_name, endorser_id, pinned')
  .eq('endorsee_id', targetUserId)
  .eq('hidden', false)
```

## 3. Defense-in-Depth Owner Scoping on Writes

Every client-triggered `update` or `delete` must filter by **both** row ID and owner ID, even when Postgres RLS policies exist:

```tsx
// GOOD: explicit owner filter alongside primary key
await db
  .from('experiences')
  .delete()
  .eq('id', experienceId)
  .eq('user_id', user.id)

// RISKY: relies 100% on RLS never regressing or never being called via a server route
await db.from('experiences').delete().eq('id', experienceId)
```

## 4. Baseline Postgres / Supabase RLS Template

Always precede `CREATE POLICY` with `DROP POLICY IF EXISTS` so migrations remain idempotent:

```sql
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Profiles are viewable by everyone" ON public.profiles;
CREATE POLICY "Profiles are viewable by everyone"
  ON public.profiles FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

ALTER TABLE public.user_skills ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Skills are viewable by everyone" ON public.user_skills;
CREATE POLICY "Skills are viewable by everyone"
  ON public.user_skills FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Users manage own skills" ON public.user_skills;
CREATE POLICY "Users manage own skills"
  ON public.user_skills FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);
```

> **Note:** If `profiles` stores sensitive PII or moderation notes, move sensitive columns to a separate `profile_private` / `user_moderation` table with owner/admin-only `SELECT` RLS so `USING (true)` on `public.profiles` never exposes private data via direct PostgREST queries.
