# Media Upload & Cropping Pipeline

Reliable avatar and cover banner upload flows require five coordinated details: accessible triggers, input value resets, client-side size/type validation, aspect-locked cropping, and URL cache-busting on stable storage keys.

## 1. Hidden File Input + Same-File Re-Select Fix

If a user picks `photo.png`, cancels the crop dialog, and clicks `photo.png` again, the browser will **not** fire `onChange` unless `e.target.value` was cleared immediately upon selection:

```tsx
<input
  ref={fileInputRef}
  type="file"
  accept="image/png,image/jpeg,image/webp"
  aria-label="Upload profile photo"
  className="hidden"
  onChange={async (e) => {
    const file = e.target.files?.[0]
    e.target.value = '' // Critical: allows re-selecting the same file after cancel
    if (!file) return
    if (file.size > 2 * 1024 * 1024) {
      toast.error('Image must be under 2 MB')
      return
    }
    setPendingImage(await readFileAsDataUrl(file))
  }}
/>
```

## 2. Accessible Overlay Controls

Icon-only camera and remove buttons over an avatar or banner **must** provide explicit `aria-label` attributes, stop event propagation when nested, and disable interaction while `uploading` is active:

```tsx
{isEditing && !uploading && (
  <button
    type="button"
    aria-label="Change profile photo"
    onClick={() => fileInputRef.current?.click()}
    className="absolute bottom-0 right-0 flex h-8 w-8 items-center justify-center rounded-full border border-border bg-background shadow-sm"
  >
    <Camera className="h-4 w-4" />
  </button>
)}

{isEditing && !uploading && avatarUrl && (
  <button
    type="button"
    aria-label="Remove profile photo"
    onClick={(e) => {
      e.stopPropagation()
      onRemove()
    }}
    className="absolute top-0 right-0 flex h-7 w-7 items-center justify-center rounded-full border border-border bg-background shadow-sm"
  >
    <X className="h-3.5 w-3.5" />
  </button>
)}
```

## 3. Aspect-Locked Crop Before Upload

- **Avatar:** `aspect={1}` (`1:1`), circular preview mask (`cropShape="round"`), exported at max `512x512` JPEG/WebP (`quality: 0.9`).
- **Cover Banner:** `aspect={3}` or `aspect={16 / 5}`, rectangular mask, exported at max `1600x500` JPEG/WebP (`quality: 0.88`).

Cropping client-side via `<canvas>` before upload normalizes EXIF orientation, strips unintended metadata, and keeps uploaded payloads well under size caps.

## 4. Deterministic Storage Key + Cache-Busting Query Token

Storing user media at a deterministic per-user key (`${user.id}/avatar.webp` with `upsert: true`) prevents orphaned files from accumulating in object storage. However, because the URL path never changes, browsers and CDNs will continue rendering the old image unless you append a version query parameter:

```tsx
const uploadAvatar = async (file: File) => {
  if (file.size > 2 * 1024 * 1024) {
    toast.error('Image must be under 2 MB')
    return
  }

  setUploadingAvatar(true)
  try {
    const ext = (file.name.split('.').pop() || 'webp').toLowerCase()
    const path = `${user.id}/avatar.${ext}`

    const { error: uploadError } = await storage
      .from('avatars')
      .upload(path, file, { upsert: true, contentType: file.type })

    if (uploadError) {
      toast.error('Photo upload failed — verify storage bucket permissions')
      return
    }

    const { data: { publicUrl } } = storage.from('avatars').getPublicUrl(path)
    const cacheBustedUrl = `${publicUrl}?t=${Date.now()}`

    const { error: dbError } = await db
      .from('profiles')
      .update({ avatar_url: cacheBustedUrl })
      .eq('id', user.id)

    if (dbError) {
      toast.error('Failed to save profile photo')
      return
    }

    updateForm({ avatarUrl: cacheBustedUrl })
    setSnapshot((prev) => ({ ...prev, avatarUrl: cacheBustedUrl }))
    toast.success('Photo updated!')
  } finally {
    setUploadingAvatar(false)
  }
}
```

## 5. Storage Bucket Policy Checklist (Supabase / S3-Compatible)

- Scope writes to the owner's prefix: `(storage.foldername(name))[1] = auth.uid()::text`.
- Restrict bucket `allowed_mime_types` to `['image/jpeg', 'image/png', 'image/webp']` (never allow `image/svg+xml` on user-uploaded public buckets due to stored XSS risk).
- Set server-side `file_size_limit` (`2097152` for avatars, `5242880` for covers) to back up the client guard.
