# Onboarding, Completeness & Verification Readiness

How to connect first-run `/onboarding`, ongoing `/profile` completeness nudges, and `/verify` trust gates into a cohesive user journey without trapping or nagging users.

## 1. First-Run Onboarding Guard (`/onboarding`)

Always check `onboarding_completed` on mount so returning users who hit Back or open a stale bookmark are redirected immediately:

```tsx
useEffect(() => {
  const checkOnboarding = async () => {
    const { data: { user } } = await auth.getUser()
    if (!user) {
      router.replace('/login')
      return
    }
    const { data: profile } = await db
      .from('profiles')
      .select('onboarding_completed')
      .eq('id', user.id)
      .single()

    if (profile?.onboarding_completed) {
      router.replace('/dashboard')
      return
    }
    setLoading(false)
  }
  checkOnboarding()
}, [])
```

### Multi-Step Wizard Principles
- Keep first-run onboarding to **3–4 lightweight steps** (e.g., Bio & Location -> Core Skills/Interests -> Goals -> Review). Leave secondary items (cover banner, social URLs, work history) for `/profile`.
- Offer **one-tap suggested chips** alongside custom entry and prevent case-insensitive duplicates (`items.some(i => i.name.toLowerCase() === candidate.toLowerCase())`).
- Persist `onboarding_completed: true` in the same completion flow and batch sub-table inserts cleanly.

## 2. Searchable Country / Location Selector

Long `<Select>` lists (190+ countries or timezones) become unusable on mobile without inline filtering:

- Store canonical country/region strings in a shared constant (`COUNTRIES`).
- Filter client-side with `country.toLowerCase().includes(query.trim().toLowerCase())`.
- Keep the selected value visible even when the search query changes.

## 3. Self-Hiding Profile Completeness Card

A completeness card drives activation for new accounts, but becomes visual noise once finished. Always return `null` at `100%`:

```tsx
const checklist = [
  { label: 'Add a profile photo', done: hasAvatar },
  { label: 'Add a cover banner', done: hasCover },
  { label: 'Write a headline', done: hasHeadline },
  { label: 'Write a short bio', done: hasBio },
  { label: 'Set your location', done: hasLocation },
  { label: 'Add at least one primary skill or tag', done: hasPrimarySkill },
]

const doneCount = checklist.filter((item) => item.done).length
const percent = Math.round((doneCount / checklist.length) * 100)

if (percent === 100) return null
```

## 4. Verification & Trust Eligibility Deep-Linking

When the app includes identity verification (`/verify`) or trust badges, evaluate profile readiness explicitly and provide a direct action link back to `/profile` when fields are missing:

```tsx
const profileReady = Boolean(profile?.name && profile?.bio && profile?.avatar_url)

const eligibility = {
  profileComplete: {
    ok: profileReady,
    detail: profileReady
      ? 'Name, bio, and profile photo are set'
      : 'Add your name, bio, and profile photo before applying',
    fixHref: '/profile',
  },
}
```

Ensure private verification documents (passports, IDs) upload to a **private** bucket (`kyc-docs`, `public = false`) served only via short-lived signed URLs to authorized reviewers — never to the public `avatars` bucket.
