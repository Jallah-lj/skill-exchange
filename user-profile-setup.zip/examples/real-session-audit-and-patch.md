# Worked Session Example — Audit, Patch & Verify

A complete session showing how `user-profile-setup` audits an existing Next.js + Supabase SaaS profile flow, produces a ranked report, applies minimal surgical fixes, and verifies the delta.

---

## Buyer Prompt

> Audit our `/profile` and `/profile/[id]` pages, fix any stale-avatar, security, or UX bugs you find, and add a self-hiding profile completeness card so new members finish setting up their profile.

---

## Step 1 — Intake & Static Scan (`AUDIT`)

Detected stack from `package.json` and `app/`:
- **Framework:** Next.js App Router + TypeScript
- **Data & Storage:** `@supabase/supabase-js` (`profiles`, `user_skills`, `endorsements`, Storage bucket `avatars`)
- **UI & Feedback:** `components/ui/*` + `sonner` toasts

Scanner execution:
```bash
python3 -B scripts/audit_profile_flow.py . --format text
```

### Ranked Findings

| # | Severity | Rule | Location | Issue |
|---|---|---|---|---|
| 1 | **HIGH** | `PF002` | `hooks/use-profile.ts:194` | `avatars` upload uses `upsert: true` + `getPublicUrl` without a cache-busting query token — re-uploaded avatars show the old cached photo until hard refresh. |
| 2 | **MEDIUM** | `PF003` | `components/profile/avatar-upload.tsx:61` | `<input type="file">` does not reset `e.target.value = ''`, breaking same-file re-selection after crop cancel. |
| 3 | **MEDIUM** | `PF008` | `app/(main)/profile/[id]/page.tsx:85` | Public profile route runs `profiles.select('*')`, exposing internal moderation columns (`banned`, `suspended`, `email`) in network payloads. |
| 4 | **MEDIUM** | `PF001` | `hooks/use-profile.ts:350` | `user_skills.delete()` filters by `id` without explicit `.eq('user_id', user.id)` owner scoping. |

---

## Step 2 — Surgical Patch (`REFINE` + `BUILD`)

### 1. Cache-Bust Avatar Overwrites & Scope Skill Deletes (`hooks/use-profile.ts`)
```tsx
const { data: { publicUrl } } = supabase.storage.from('avatars').getPublicUrl(path)
const cacheBustedUrl = `${publicUrl}?t=${Date.now()}`

const { error } = await supabase
  .from('profiles')
  .update({ avatar_url: cacheBustedUrl })
  .eq('id', user.id)
```

```tsx
const removeSkill = async (id: string) => {
  if (!userId) return
  const { error } = await supabase
    .from('user_skills')
    .delete()
    .eq('id', id)
    .eq('user_id', userId)
  if (error) {
    toast.error('Failed to remove skill')
    return
  }
  setSkills((prev) => prev.filter((s) => s.id !== id))
}
```

### 2. Project Explicit Public Columns (`app/(main)/profile/[id]/page.tsx`)
```tsx
const PUBLIC_PROFILE_FIELDS =
  'id, name, username, headline, bio, location, availability, avatar_url, cover_image_url, website_url, kyc_status, created_at'

const { data: profileData } = await supabase
  .from('profiles')
  .select(PUBLIC_PROFILE_FIELDS)
  .eq('id', id)
  .single()
```

### 3. Add Self-Hiding `ProfileCompletenessCard` (`components/profile/profile-completeness-card.tsx`)
Renders a progress bar and checklist across avatar, headline, bio, location, and skills — and returns `null` automatically once completeness reaches `100%`.

---

## Step 3 — Verification Delta (`VERIFY`)

- `python3 -B scripts/audit_profile_flow.py . --format text` -> **0 findings** (`exit code 0`, down from 4).
- `npx tsc --noEmit` -> **0 errors**.
- Functional gates verified: Cancel restores `snapshot`, re-uploading an avatar refreshes immediately without page reload, and `/profile/[id]` network payload contains only public fields.
