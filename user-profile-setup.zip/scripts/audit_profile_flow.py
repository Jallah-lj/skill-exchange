#!/usr/bin/env python3
"""Read-only static analyzer for user profile, media upload, and onboarding flows.

Standard library only. Zero network calls. Zero file writes.

Usage:
    python3 -B scripts/audit_profile_flow.py <project-dir> [--format text|json]
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, List

SKIP_DIRS = {
    ".git",
    ".next",
    ".nuxt",
    ".svelte-kit",
    ".turbo",
    ".venv",
    ".claude",
    "__pycache__",
    "agensi-package",
    "build",
    "coverage",
    "dist",
    "node_modules",
    "out",
    "target",
}

CODE_EXTENSIONS = {".ts", ".tsx", ".js", ".jsx", ".vue", ".svelte"}

PROFILE_PATH_KEYWORDS = (
    "profile",
    "onboarding",
    "avatar",
    "cover",
    "endorsement",
    "verify",
    "verification",
    "account",
)

PUBLIC_ROUTE_SEGMENTS = ("[id]", "[userid]", "[username]", "[handle]", "[slug]")

ICON_COMPONENT_RE = re.compile(
    r"<(?:Camera|X|Trash2?|Pencil|Edit2?|Upload|Pin|EyeOff|Eye|ImagePlus)\b"
)


@dataclass
class Finding:
    rule_id: str
    severity: str  # high | medium | low
    confidence: str  # high | medium
    title: str
    file: str
    line: int
    detail: str
    fix: str


def is_profile_related(rel_path: str) -> bool:
    lowered = rel_path.lower().replace("\\", "/")
    if "/admin/" in lowered or ".test." in lowered or ".spec." in lowered:
        return False
    return any(keyword in lowered for keyword in PROFILE_PATH_KEYWORDS)


def iter_profile_files(root: Path) -> Iterable[Path]:
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(d for d in dirnames if d not in SKIP_DIRS)
        for filename in sorted(filenames):
            ext = Path(filename).suffix.lower()
            if ext not in CODE_EXTENSIONS:
                continue
            full_path = Path(dirpath) / filename
            rel_path = full_path.relative_to(root).as_posix()
            if is_profile_related(rel_path):
                yield full_path


def line_number_at(text: str, index: int) -> int:
    return text.count("\n", 0, index) + 1


def extract_brace_block(text: str, open_brace_index: int, max_len: int = 4000) -> str:
    """Return substring inside balanced `{ ... }` starting at `open_brace_index`."""
    depth = 0
    end = min(len(text), open_brace_index + max_len)
    in_str: str | None = None
    escaped = False
    for idx in range(open_brace_index, end):
        ch = text[idx]
        if in_str:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == in_str:
                in_str = None
            continue
        if ch in ("'", '"', "`"):
            in_str = ch
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text[open_brace_index : idx + 1]
    return text[open_brace_index:end]


def scan_file(path: Path, root: Path) -> List[Finding]:
    findings: List[Finding] = []
    rel = path.relative_to(root).as_posix()
    lowered_rel = rel.lower()
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return findings

    # PF001: Mutation on profile or sub-tables missing explicit owner scoping
    mutation_re = re.compile(
        r"\.from\(\s*['\"](profiles|user_skills|experiences|endorsements)['\"]\s*\)"
        r"\s*\.\s*(update|delete)\s*\([^;]*?(?=\n\s*\n|;\s*$|\n\s*(?:const|let|if|return)\b)",
        re.DOTALL | re.MULTILINE,
    )
    owner_cols = {
        "profiles": ("id",),
        "user_skills": ("user_id",),
        "experiences": ("user_id",),
        "endorsements": ("endorsee_id", "endorser_id", "user_id"),
    }
    for match in mutation_re.finditer(text):
        table = match.group(1)
        action = match.group(2)
        snippet = match.group(0)
        lineno = line_number_at(text, match.start())
        expected_cols = owner_cols[table]
        has_owner_eq = any(
            re.search(rf"\.eq\(\s*['\"]{col}['\"]", snippet) for col in expected_cols
        )
        expected_filters = ", ".join(f".eq('{c}', ...)" for c in expected_cols)
        if not has_owner_eq:
            severity = "high" if table == "profiles" else "medium"
            findings.append(
                Finding(
                    rule_id="PF001",
                    severity=severity,
                    confidence="high",
                    title=f"Unscoped `{table}.{action}()` missing explicit owner filter",
                    file=rel,
                    line=lineno,
                    detail=(
                        f"`{table}.{action}()` does not chain an explicit owner filter "
                        f"({expected_filters})."
                    ),
                    fix=(
                        f"Chain `.eq('{expected_cols[0]}', user.id)` alongside primary-key filters "
                        "for defense-in-depth with database RLS."
                    ),
                )
            )

    # PF002: Upsert storage upload + getPublicUrl without cache-busting parameter
    upsert_re = re.compile(
        r"storage\s*\.from\(\s*['\"]([^'\"]+)['\"]\s*\)\s*\.upload\([^)]*upsert\s*:\s*true",
        re.DOTALL,
    )
    for match in upsert_re.finditer(text):
        bucket = match.group(1)
        window = text[match.start() : match.start() + 1200]
        if "getPublicUrl" in window and not re.search(
            r"\?[tv]=|Date\.now\(\)|updated_at|cacheBust", window
        ):
            findings.append(
                Finding(
                    rule_id="PF002",
                    severity="high",
                    confidence="high",
                    title=f"Stable `{bucket}` upload missing URL cache-buster",
                    file=rel,
                    line=line_number_at(text, match.start()),
                    detail=(
                        f"Overwrites object in `{bucket}` with `upsert: true` and reads `getPublicUrl` "
                        "without appending a version query token, causing stale cached avatars/covers."
                    ),
                    fix="Append `?t=${Date.now()}` to `publicUrl` before saving to state/DB.",
                )
            )

    # PF003: <input type="file"> without clearing target.value
    file_input_re = re.compile(r"<input\b[^>]*type=['\"]file['\"][\s\S]{0,600}?/>")
    for match in file_input_re.finditer(text):
        snippet = match.group(0)
        if "onChange" in snippet and not re.search(
            r"\.value\s*=\s*['\"]['\"]", snippet
        ):
            findings.append(
                Finding(
                    rule_id="PF003",
                    severity="medium",
                    confidence="high",
                    title="File `<input>` missing `e.target.value = ''` reset",
                    file=rel,
                    line=line_number_at(text, match.start()),
                    detail=(
                        "If the user cancels cropping or removes an image and re-selects the same file, "
                        "browsers will not trigger `onChange` unless `e.target.value` is reset."
                    ),
                    fix="Set `e.target.value = ''` immediately after reading `e.target.files?.[0]`.",
                )
            )

    # PF004: Storage upload without client-side file.size validation
    upload_call_re = re.compile(r"storage\s*\.from\(\s*['\"]([^'\"]+)['\"]\s*\)\s*\.upload\(")
    for match in upload_call_re.finditer(text):
        bucket = match.group(1)
        window_start = max(0, match.start() - 600)
        window = text[window_start : match.end() + 200]
        if ".size" not in window and "MAX_" not in window and "maxSize" not in window:
            findings.append(
                Finding(
                    rule_id="PF004",
                    severity="medium",
                    confidence="medium",
                    title=f"Upload to `{bucket}` lacks client-side file size guard",
                    file=rel,
                    line=line_number_at(text, match.start()),
                    detail=(
                        f"Uploads to `{bucket}` without checking `file.size` nearby, risking stalled "
                        "mobile uploads or opaque storage errors on large camera photos."
                    ),
                    fix="Validate `file.size` (e.g., 2 MB for avatars, 5 MB for covers) before uploading.",
                )
            )

    # PF005: Sequential await waterfall (3+ sequential awaits on db/supabase without Promise.all)
    fn_blocks = re.finditer(
        r"(?:const\s+\w+\s*=\s*async\s*\([^)]*\)\s*=>\s*\{|async\s+function\s+\w+\s*\([^)]*\)\s*\{)",
        text,
    )
    for fn_match in fn_blocks:
        brace_idx = fn_match.end() - 1
        block = extract_brace_block(text, brace_idx)
        await_queries = re.findall(r"await\s+\w+\.from\(\s*['\"][^'\"]+['\"]\s*\)", block)
        if len(await_queries) >= 3 and "Promise.all" not in block and "Promise.allSettled" not in block:
            findings.append(
                Finding(
                    rule_id="PF005",
                    severity="medium",
                    confidence="medium",
                    title="Sequential `await` waterfall in profile/onboarding handler",
                    file=rel,
                    line=line_number_at(text, fn_match.start()),
                    detail=(
                        f"Found {len(await_queries)} sequential database `await` calls inside one async "
                        "function without `Promise.all`, adding avoidable round-trip latency."
                    ),
                    fix="Batch independent reads or sibling inserts with `Promise.all([...])`.",
                )
            )

    # PF006: Icon-only <button> without aria-label or sr-only text
    button_re = re.compile(r"<button\b([^>]*)>([\s\S]{1,300}?)</button>")
    for match in button_re.finditer(text):
        attrs, inner = match.group(1), match.group(2)
        if "aria-label" in attrs or "aria-labelledby" in attrs or "sr-only" in inner:
            continue
        # Strip JSX tags and expressions to check if visible literal text exists
        visible_text = re.sub(r"<[^>]+>|\{[^}]*\}", "", inner).strip()
        if not visible_text and ICON_COMPONENT_RE.search(inner):
            findings.append(
                Finding(
                    rule_id="PF006",
                    severity="medium",
                    confidence="high",
                    title="Icon-only `<button>` missing `aria-label`",
                    file=rel,
                    line=line_number_at(text, match.start()),
                    detail="Button renders an icon without visible text or `aria-label`, failing WCAG 4.1.2.",
                    fix="Add a descriptive `aria-label` (e.g., `aria-label=\"Change profile photo\"`).",
                )
            )

    # PF007: Username / handle update without unique-violation handling
    if re.search(r"\.from\(\s*['\"]profiles['\"]\s*\)\s*\.update\([\s\S]{0,400}?\busername\b", text):
        if not re.search(r"23505|P2002|already taken|unique", text, re.IGNORECASE):
            findings.append(
                Finding(
                    rule_id="PF007",
                    severity="medium",
                    confidence="medium",
                    title="Username update lacks duplicate-handle (`23505`/`P2002`) handling",
                    file=rel,
                    line=1,
                    detail="Updates `username` on `profiles` without mapping unique constraint collisions to a clear user message.",
                    fix="Check `error.code === '23505'` (or `P2002`) and show `'That username is already taken'`.",
                )
            )

    # PF008: Public profile route selecting '*' on profiles or joined profiles
    is_public_route = any(seg in lowered_rel for seg in PUBLIC_ROUTE_SEGMENTS)
    if is_public_route:
        star_re = re.compile(
            r"(?:\.from\(\s*['\"]profiles['\"]\s*\)\s*\.select\(\s*['\"]\*['\"]\s*\)"
            r"|profiles![a-zA-Z0-9_]+\(\s*\*\s*\))"
        )
        for match in star_re.finditer(text):
            findings.append(
                Finding(
                    rule_id="PF008",
                    severity="medium",
                    confidence="high",
                    title="Public profile route selects `*` from `profiles`",
                    file=rel,
                    line=line_number_at(text, match.start()),
                    detail=(
                        "Selecting `*` on a public profile route can expose internal moderation, "
                        "contact, or account-state columns in client network payloads."
                    ),
                    fix="Project an explicit public column list (`id, name, username, headline, bio, avatar_url, ...`).",
                )
            )

    return findings


def rank_findings(findings: List[Finding]) -> List[Finding]:
    sev_rank = {"high": 0, "medium": 1, "low": 2}
    conf_rank = {"high": 0, "medium": 1}
    return sorted(
        findings,
        key=lambda f: (sev_rank.get(f.severity, 9), conf_rank.get(f.confidence, 9), f.file, f.line),
    )


def format_text(root: Path, scanned_files: List[str], findings: List[Finding]) -> str:
    counts = {
        "high": sum(1 for f in findings if f.severity == "high"),
        "medium": sum(1 for f in findings if f.severity == "medium"),
        "low": sum(1 for f in findings if f.severity == "low"),
    }
    lines = [
        f"Profile & Onboarding Static Audit — {root.name}",
        f"Files scanned: {len(scanned_files)} | Findings: {len(findings)} "
        f"(high: {counts['high']}, medium: {counts['medium']}, low: {counts['low']})",
        "-" * 72,
    ]
    if not findings:
        lines.append("PASS: No static profile or onboarding issues detected.")
        return "\n".join(lines)

    for idx, f in enumerate(findings, start=1):
        lines.append(
            f"{idx}. [{f.severity.upper()}] {f.rule_id} — {f.title}\n"
            f"   Location : {f.file}:{f.line} (confidence: {f.confidence})\n"
            f"   What     : {f.detail}\n"
            f"   Fix      : {f.fix}"
        )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Read-only static audit for user profile setup, media upload, and onboarding code."
    )
    parser.add_argument("project_dir", help="Path to the target web project root")
    parser.add_argument(
        "--format",
        choices=("text", "json"),
        default="text",
        help="Output format (default: text)",
    )
    args = parser.parse_args()

    root = Path(args.project_dir).resolve()
    if not root.exists() or not root.is_dir():
        print(f"Error: directory not found: {root}", file=sys.stderr)
        return 2

    files = list(iter_profile_files(root))
    rel_files = [f.relative_to(root).as_posix() for f in files]

    all_findings: List[Finding] = []
    for fpath in files:
        all_findings.extend(scan_file(fpath, root))

    ranked = rank_findings(all_findings)

    if args.format == "json":
        payload = {
            "project": root.name,
            "files_scanned": len(rel_files),
            "scanned_paths": rel_files,
            "summary": {
                "total": len(ranked),
                "high": sum(1 for f in ranked if f.severity == "high"),
                "medium": sum(1 for f in ranked if f.severity == "medium"),
                "low": sum(1 for f in ranked if f.severity == "low"),
            },
            "findings": [asdict(f) for f in ranked],
        }
        print(json.dumps(payload, indent=2))
    else:
        print(format_text(root, rel_files, ranked))

    has_actionable = any(f.severity in ("high", "medium") for f in ranked)
    return 1 if has_actionable else 0


if __name__ == "__main__":
    sys.exit(main())
